//
//  ApiManager.h
//  ApiManager
//
//  Created by Sathish on 03/01/19.
//  Copyright © 2019 Full. All rights reserved.
//

#import <UIKit/UIKit.h>

//! Project version number for ApiManager.
FOUNDATION_EXPORT double ApiManagerVersionNumber;

//! Project version string for ApiManager.
FOUNDATION_EXPORT const unsigned char ApiManagerVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <ApiManager/PublicHeader.h>


